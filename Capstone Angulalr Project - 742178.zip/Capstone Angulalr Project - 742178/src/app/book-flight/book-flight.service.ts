import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import {tap, catchError} from 'rxjs/operators';
import {HttpErrorResponse} from '@angular/common/http';
import {Flight} from '../shared/Flight';
import { FlightBooking } from '../shared/FlightBooking';

@Injectable()
export class BookFlightService {

  errorMessage: String;

  constructor(private http: HttpClient) { }

  getData(data:any){
   //Consume the exposed REST api from http://localhost:1020/bookFlight
    const options = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post("http://localhost:1020/bookFlight",data, {headers: options})
    .pipe(tap(data => console.log('Data Fetched: '+ JSON.stringify(data))),catchError(this.handleError));
  }

  private handleError(err:HttpErrorResponse) {
    let errMsg:string='';
    if (err.error instanceof Error) {
       // A client-side or network error occurred. Handle it accordingly.
       console.log('An error occurred:', err.error.message);
        errMsg=err.error.message;} 
       else {
       // The backend returned an unsuccessful response code.
       // The response body may contain clues as to what went wrong,
       console.log(`Backend returned code ${err.status}`);
          errMsg=err.error.status;
     }
        return throwError(errMsg); 
  }
}
