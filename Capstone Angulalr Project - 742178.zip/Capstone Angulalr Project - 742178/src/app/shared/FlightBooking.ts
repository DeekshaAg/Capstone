export class FlightBooking{
  
    bookingId:any;
    passengerName:any;
    noOfTickets:any;
    totalAmount:any; 
    flightId:any;
    
}