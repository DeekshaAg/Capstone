export class FlightBooking{
  
    bookingid:any;
    passengername:any;
    nooftickets:any;
    totalamount:any; 
    flightid:any;
    
}