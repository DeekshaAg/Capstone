import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormControl, FormGroup } from '@angular/forms';
import { BookFlightService } from "./book-flight.service";
import {Flight} from '../shared/Flight';
import { FlightBooking } from '../shared/FlightBooking';

@Component({
  selector: 'app-book-flight',
  templateUrl: './book-flight.component.html',
  styleUrls: ['./book-flight.component.css'],
  providers: [BookFlightService]
})
export class BookFlightComponent implements OnInit {

  errorMessage: any;
  successMessage: any;
  bookingForm: FormGroup;
  
  flightBookings:FlightBooking[];
  constructor(private fb: FormBuilder, private bookFlightService: BookFlightService) { }

  

  ngOnInit() {
    this.bookingForm = this.fb.group({
      passengerName: ['',[Validators.required]],
      noOfTickets: [0,[Validators.required, Validators.min(1)]],
      flightId: ['',[Validators.required, Validators.pattern('[a-zA-z]{3}-[0-9]{3}')]]
    })
  }



  book(inputForm) {
    // Code the method here
    console.log(inputForm.value);
    this.bookFlightService.getData(inputForm.value).
    subscribe(successMessage => this.successMessage=<any>successMessage,
      errorMessage => this.errorMessage=<any>errorMessage);
    
  }
}

function validateFlight(flightId : string) {
 /* 
    Code the validator here
    Use flightError as the property
*/
  

}


