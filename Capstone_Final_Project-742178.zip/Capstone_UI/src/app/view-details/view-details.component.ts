import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators,FormsModule } from '@angular/forms';
import { ViewDetailsService } from "./view-details.service";
import { FlightBooking } from '../shared/FlightBooking';

@Component({
  selector: 'app-view-details',
  templateUrl: './view-details.component.html',
  styleUrls: ['./view-details.component.css'],
  providers: [ViewDetailsService]
})
export class ViewDetailsComponent implements OnInit {

  flightbookings : FlightBooking[];
  
  errorMessage : string;
  successMessage:  string;
  

  constructor(private viewDetailService : ViewDetailsService) {

   }

  ngOnInit() {
    this.view();
}

  view() {
    return this.viewDetailService.view().subscribe(
      flightbookings => this.flightbookings = flightbookings,
      errorMessage => this.errorMessage = <any>errorMessage
    );
      
  }

  delete(id) {
    this.viewDetailService.delete(id).subscribe(
      successMessage => this.successMessage=<any>successMessage,
      errorMessage => this.errorMessage=<any>errorMessage
    );
    this.view();
  }

}

