package io.capstone.service;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import io.capstone.model.Flightbooking;
import io.capstone.repository.FlightBookingRepository;

@Service
public class FlightBookingService {
	
	@Autowired
	private FlightBookingRepository flightBookingRepository;
	
	public List<Flightbooking> getAllBookings() {
		List<Flightbooking> bookings = new ArrayList<>();
		flightBookingRepository.findAll().forEach(bookings :: add);
		return bookings;
	}
	
	public Flightbooking createBooking(Flightbooking flightBooking) {
		Flightbooking booking = flightBookingRepository.save(flightBooking);
		List<Flightbooking> bookings=this.getAllBookings();
		ListIterator<Flightbooking> item = bookings.listIterator();
		long max=0;
		while(item.hasNext()) {
			long id= item.next().getBookingid();
			if(id>max) {
				max=id;
			}
		}
		booking.setBookingid(max);
		return booking;
	}
	
	public long deleteBooking(long bookingId) {
		flightBookingRepository.deleteById(bookingId);
		return bookingId;
	}

}
