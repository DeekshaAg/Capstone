package io.capstone.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Flightbooking {
	
	@Id
	private long bookingid;
	private String passengername;
	private int nooftickets;
	private int totalamount;
	private String flightid;
	
	
	public Flightbooking() {}


	public Flightbooking(int bookingid, String passengername, int nooftickets, int totalamount, String flightid) {
		super();
		this.bookingid = bookingid;
		this.passengername = passengername;
		this.nooftickets = nooftickets;
		this.totalamount = totalamount;
		this.flightid = flightid;
	}


	public long getBookingid() {
		return bookingid;
	}


	public void setBookingid(long bookingid) {
		this.bookingid = bookingid;
	}


	public String getPassengername() {
		return passengername;
	}


	public void setPassengername(String passengername) {
		this.passengername = passengername;
	}


	public int getNooftickets() {
		return nooftickets;
	}


	public void setNooftickets(int nooftickets) {
		this.nooftickets = nooftickets;
	}


	public int getTotalamount() {
		return totalamount;
	}


	public void setTotalamount(int totalamount) {
		this.totalamount = totalamount;
	}


	public String getFlightid() {
		return flightid;
	}


	public void setFlightid(String flightid) {
		this.flightid = flightid;
	}
	
	
	
}
