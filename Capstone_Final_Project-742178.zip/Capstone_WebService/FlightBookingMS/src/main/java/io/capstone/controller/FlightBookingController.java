package io.capstone.controller;

import org.springframework.web.client.RestTemplate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import io.capstone.model.Flightbooking;
import io.capstone.service.FlightBookingCircuit;
import io.capstone.service.FlightBookingService;
import io.capstone.service.UpdateSeatsCircuit;
import io.capstone.model.*;
import org.springframework.web.bind.annotation.RequestBody;

@RestController
@CrossOrigin
public class FlightBookingController {

	@Autowired
	private FlightBookingService flightBookingService;
	
	@Autowired
	private FlightBookingCircuit flightBookingCircuit;
	
	@Autowired
	private UpdateSeatsCircuit updateSeatsCircuit;
	
	@RequestMapping("/getallId")
	public List<Flightbooking> getAllBookings(){
		return flightBookingService.getAllBookings();
	}
	
	@RequestMapping(method=RequestMethod.DELETE,value="/delete/{id}")
	public long deleteBooking(@PathVariable("id") int bookingId) {
		return flightBookingService.deleteBooking(bookingId);
	}
	
	@RequestMapping(method = RequestMethod.POST, value="/bookFlight")
	public Flightbooking bookFlight(@RequestBody FormInfo formInfo) {
		Flightbooking flightBooking = new Flightbooking();
		
		Flight flight = flightBookingCircuit.getFlight(formInfo.getFlightId());
		
		if(flight.getAvailableseats()>=formInfo.getNoOfTickets() && flight.getStatus().contains("Running")) {
			int availableseats = flight.getAvailableseats() - formInfo.getNoOfTickets();
			flight.setAvailableseats(availableseats);
			
			updateSeatsCircuit.updateSeats(flight);
			
			flightBooking.setFlightid(formInfo.getFlightId());
			flightBooking.setNooftickets(formInfo.getNoOfTickets());
			flightBooking.setPassengername(formInfo.getPassengerName());
			flightBooking.setTotalamount(formInfo.getNoOfTickets()*flight.getFare());
			
			long bookingid=flightBookingService.createBooking(flightBooking).getBookingid();
			flightBooking.setBookingid(bookingid);
			return flightBooking;
			}else {
				return flightBooking;
	}}
}
