package io.capstone.repository;

import org.springframework.data.repository.CrudRepository;

import io.capstone.model.Flightbooking;

public interface FlightBookingRepository extends CrudRepository<Flightbooking,Long> {

}
