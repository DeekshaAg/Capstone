package io.capstone.model;

public class FormInfo {
	
	private String flightId;
	private String passengerName;
	private int noOfTickets;
	
	public FormInfo() {}

	public FormInfo(String flightId, String passengerName, int noOfTickets) {
		super();
		this.flightId = flightId;
		this.passengerName = passengerName;
		this.noOfTickets = noOfTickets;
	}

	public String getFlightId() {
		return flightId;
	}

	public void setFlightId(String flightId) {
		this.flightId = flightId;
	}

	public String getPassengerName() {
		return passengerName;
	}

	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}

	public int getNoOfTickets() {
		return noOfTickets;
	}

	public void setNoOfTickets(int noOfTickets) {
		this.noOfTickets = noOfTickets;
	}
	
	

}
