package io.capstone.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import io.capstone.model.*;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class UpdateSeatsCircuit {
	
	@Autowired
	private RestTemplate restTemplate;
	
	@HystrixCommand(fallbackMethod="updateSeatsFallback")
	public void updateSeats(Flight flight) {
		restTemplate.put("http://flightinfoms/book/"+flight.getFlightid(), flight);
	}
	
	public void updateSeatsFallback(Flight flight) {
		
	}
	
}
