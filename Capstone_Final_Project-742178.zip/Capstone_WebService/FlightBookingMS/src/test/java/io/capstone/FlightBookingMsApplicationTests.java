package io.capstone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightBookingMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
