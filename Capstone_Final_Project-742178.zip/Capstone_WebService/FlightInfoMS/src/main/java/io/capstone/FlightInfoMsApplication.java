package io.capstone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlightInfoMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlightInfoMsApplication.class, args);
	}

}
