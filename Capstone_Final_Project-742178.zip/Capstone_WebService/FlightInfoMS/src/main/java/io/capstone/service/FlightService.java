package io.capstone.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import io.capstone.model.Flight;
import io.capstone.repository.FlightRepository;

@Service
public class FlightService {
	
	@Autowired
	private FlightRepository flightRepository; 
	
	public List<Flight> getAllFlights() {
		
		List<Flight> flights = new ArrayList<>();
			flights = flightRepository.findByStatus("Running");
		return flights;
	}
	
	public Flight getFlightById(String Id) {
		
		return flightRepository.findById(Id).get();
	}
	
	public Flight updateFlight(Flight flight) {
		
		return flightRepository.save(flight);
	}
}
