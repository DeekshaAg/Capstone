package io.capstone.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import io.capstone.model.Flight;

public interface FlightRepository extends CrudRepository<Flight, String>{
	
	public List<Flight> findByStatus(String status);
}
