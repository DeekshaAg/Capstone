package io.capstone.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Flight {
	
	@Id
	private String flightid;
	private String aircraftname;
	private int fare;
	private int availableseats;
	private String status;
	
	public Flight() {}
	
	public Flight(String flightid, String aircraftname, int fare, int availableseats, String status) {
		super();
		this.flightid = flightid;
		this.aircraftname = aircraftname;
		this.fare = fare;
		this.availableseats = availableseats;
		this.status = status;
	}

	public String getFlightid() {
		return flightid;
	}

	public void setFlightid(String flightid) {
		this.flightid = flightid;
	}

	public String getAircraftname() {
		return aircraftname;
	}

	public void setAircraftname(String aircraftname) {
		this.aircraftname = aircraftname;
	}

	public int getFare() {
		return fare;
	}

	public void setFare(int fare) {
		this.fare = fare;
	}

	public int getAvailableseats() {
		return availableseats;
	}

	public void setAvailableseats(int availableseats) {
		this.availableseats = availableseats;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
