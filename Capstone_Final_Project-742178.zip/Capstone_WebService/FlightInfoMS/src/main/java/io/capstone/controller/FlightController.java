package io.capstone.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import io.capstone.service.FlightService;
import io.capstone.model.*;
@RestController
@CrossOrigin
public class FlightController {
	
	@Autowired
	private FlightService flightService;
	
	@RequestMapping("/book")
	public List<Flight> getAllFlights(){
		
		return flightService.getAllFlights();
	}
	
	@RequestMapping("/book/{id}")
	public Flight getFlightById(@PathVariable("id") String Id) {
		System.out.print("I was called to get flight details");
		return flightService.getFlightById(Id);
	}
	
	@RequestMapping(method = RequestMethod.PUT,value="book/{id}")
	public Flight updateFlight(@RequestBody Flight flight) {
		System.out.print("I was called to update flights");
		return flightService.updateFlight(flight);
	}
}
